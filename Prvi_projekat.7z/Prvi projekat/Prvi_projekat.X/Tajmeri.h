#include <p30fxxxx.h>

void Init_T1(void);
void Init_T2(void);
