#include <p30fxxxx.h>

void initUART1(void);
void RS232_putstr(register const char *str);
void WriteUART1(unsigned int data);