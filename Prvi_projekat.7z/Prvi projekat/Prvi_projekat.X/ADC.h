#include<p30fxxxx.h>

void ConfigureADCPins(void);
void ADCinit_analog(void);
void ADCinit(void);
